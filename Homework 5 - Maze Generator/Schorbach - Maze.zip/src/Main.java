// Grant Schorbach
// TCSS 342 - Data Structures

public class Main {

    public static void main(String[] args) {
	    int x = 15;
	    int y = 15;

	    Maze maze = new Maze(x, y, true);
	    maze.solve(maze.startx, maze.starty);
    }
}
